# Fundamentals of Agent Development Kit (ADK)

This learning path explores the evolution of AI agents that move beyond text generation to autonomous execution using Agent Development Kit (ADK). You will learn how to build and configure agents using Python and YAML, progressing from basic setups to sophisticated assistants with advanced planning and structured output capabilities.

## [Agent Fundamentals](01.md)

## [Build Your First Agent with ADK](02.md)

## [OPtimize Agent Behavior](03.md)
