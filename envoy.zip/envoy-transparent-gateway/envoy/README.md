# GRPC and PubSub filters

These filters are based on the `http-filter-example` extension in [Envoy filter example](https://github.com/envoyproxy/envoy-filter-example).

Each filter includes a sample `envoy.yaml` in the source folder.

## grpc_filter

This filter uses `descriptor_set` files produced by the Gogole Protobuf compiler (protoc) to decode GRPC dynamically.

## pubsub_filter

This filter understands (only) Google Pubsub Publish requests, and as an example performs a simple text substitution on the payload.

Configuration is added to the `envoy.yaml` file:

```yaml
- name: pubsub_filter
  config:
    find_text: "message"
    replace_text: "NEW MESSAGE"
```

## Setup

For building on MacOS, see environment setup instructions at [Building Envoy with Bazel](https://github.com/envoyproxy/envoy/blob/v1.13.1/bazel/README.md#building-envoy-with-bazel).

## Building

To build the Envoy static binary:

1. `git submodule update --init`
2. `bazel build //:envoy`

There is a docker image `envoyproxy/docker-build` available, see [Developer use of CI Docker images](https://github.com/envoyproxy/envoy/blob/master/ci/README.md). Set Docker memory to at least 4GB.

## IDE notes

### VS Code

- See [Using Clang in Visual Studio Code](https://code.visualstudio.com/docs/cpp/config-clang-mac) for an introduction
- Install VS Code extensions:
  - C/C++ `ms-vscode.cpptools`
  - vscode-bazel `bazelbuild.vscode-bazel`
  - vscode-proto3 `xh404.vscode-proto3`
  - Clang-Format `xaver.clang-format`
  - Git History `donjayamanne.githistory`
  - YAML `redhat.vscode-yaml`
- [Visual Studio Code settings](https://code.visualstudio.com/docs/cpp/customize-default-settings-cpp#_visual-studio-code-settings) to customize
  - For this project set `cppStandard` to `c++14`

#### VS Code Docker development

Extensions:

- Docker `ms-azuretools.vscode-docker`
- Remote Development `ms-vscode-remote.vscode-remote-extensionpack`

See [Developing inside a Container](https://code.visualstudio.com/docs/remote/containers).

### CLion

See <https://groups.google.com/d/msg/envoy-dev/jOkEX5X_yWY/D5-Q4Vt0DwAJ>

```text
bazel-cmakelists --targets //:envoy --skip_build
```
