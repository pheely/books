#include <string>

#include "grpc_filter.h"

#include "envoy/server/filter_config.h"
#include "envoy/buffer/buffer.h"
#include "source/common/protobuf/protobuf.h"
#include "source/common/protobuf/utility.h"
#include "source/common/grpc/common.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace GrpcFilter {

GrpcConfig::GrpcConfig(const envoy::http::grpc_filter::Config& proto_config, Api::Api& api)
    : descriptor_file_(proto_config.descriptor_file()), service_name_(proto_config.service_name()),
      method_name_(proto_config.method_name()), field_name_(proto_config.field_name()) {

  Envoy::Protobuf::FileDescriptorSet descriptor_set;

  if (!descriptor_set.ParseFromString(api.fileSystem().fileReadToEnd(descriptor_file_).value()))
    throw EnvoyException("Unable to parse proto descriptor file");

  for (const auto& file : descriptor_set.file()) {
    if (descriptor_pool_.BuildFile(file) == nullptr)
      throw EnvoyException("Unable to build proto descriptor pool");
  }

  auto service = descriptor_pool_.FindServiceByName(service_name_);
  if (service == nullptr)
    throw EnvoyException("Could not find '" + service_name_ + "' in the proto descriptor");

  prototype_message_ = [=]() -> const Protobuf::Message* {
    for (int i = 0; i < service->method_count(); ++i) {
      auto method = service->method(i);
      if (method->name() == method_name_) {
        auto input_type = method->input_type();
        ENVOY_LOG(debug, "Found method {}, full_name = {}, input_type = {}", method->name(),
                  method->full_name(), input_type->full_name());
        return factory_.GetPrototype(input_type);
      }
    }
    throw EnvoyException("Could not find method '" + method_name_ + "' for service '" +
                         service_name_ + "' in descriptor file");
  }();

  message_descriptor_ = prototype_message_->GetDescriptor();

  for (int i = 0; i < message_descriptor_->field_count(); ++i) {
    ENVOY_LOG(debug, "Field found: name '{}', full_name '{}'",
              message_descriptor_->field(i)->name(), message_descriptor_->field(i)->full_name());
  }

  field_descriptor_ = message_descriptor_->FindFieldByName(field_name_);
  if (!field_descriptor_)
    throw EnvoyException("Could not find field '" + field_name_ + "' in method '" + method_name_ +
                         "' in descriptor file");

  method_path_ = absl::StrCat("/", service_name_, "/", method_name_);
}

GrpcFilter::GrpcFilter(GrpcConfigSharedPtr config) : config_(config) {}

GrpcFilter::~GrpcFilter() {}

void GrpcFilter::onDestroy() {}

Http::FilterHeadersStatus GrpcFilter::decodeHeaders(Http::RequestHeaderMap& headers, bool) {
  if (Grpc::Common::hasGrpcContentType(headers)) {
    if (headers.Path()) {
      if (headers.Path()->value().getStringView() == config_->method_path()) {
        ENVOY_LOG(debug, "In GrpcFilter::decodeHeaders found matching path {}",
                  config_->method_path());
        matched_method_path_ = true;
      }
    }
  }
  return Http::FilterHeadersStatus::Continue;
}

namespace {
// use this because google::protobuf::Message::DebugString() formats with newlines
[[maybe_unused]] std::string protobuf_debug_string(const google::protobuf::Message& message) {
  std::string debug_string;

  google::protobuf::TextFormat::Printer printer;
  printer.SetSingleLineMode(true);

  printer.PrintToString(message, &debug_string);
  return debug_string;
}
} // namespace

Http::FilterDataStatus GrpcFilter::decodeData(Buffer::Instance& data, bool) {
  if (!matched_method_path_)
    return Http::FilterDataStatus::Continue;

  std::vector<Grpc::Frame> frames;
  decoder_.decode(data, frames); // empties the buffer

  for (auto& frame : frames) {
    ProtobufTypes::MessagePtr message{config_->prototype_message()->New()};
    if (message->ParseFromString(frame.data_.get()->toString())) {
      ENVOY_LOG(debug, "incoming message: '{}'", protobuf_debug_string(*message.get()));

      auto field_data = message->GetReflection()->GetString(*message, config_->field_descriptor());

      message->GetReflection()->SetString(message.get(), config_->field_descriptor(),
                                          field_data + " modified message");

      std::string serialized_message;
      if (message->SerializeToString(&serialized_message)) {
        ENVOY_LOG(debug, "serialized new message: '{}'", protobuf_debug_string(*message.get()));
        Buffer::OwnedImpl buffer{serialized_message};
        Envoy::Grpc::Encoder().prependFrameHeader(Envoy::Grpc::GRPC_FH_DEFAULT, buffer);
        data.add(buffer);
      } else {
        ENVOY_LOG(debug, "failed to serialize message");
      }
    } else {
      ENVOY_LOG(debug, "failed to parse message");
    }
  }
  return Http::FilterDataStatus::Continue;
}

Http::FilterTrailersStatus GrpcFilter::decodeTrailers(Http::RequestTrailerMap&) {
  return Http::FilterTrailersStatus::Continue;
}

void GrpcFilter::setDecoderFilterCallbacks(Http::StreamDecoderFilterCallbacks& callbacks) {
  decoder_callbacks_ = &callbacks;
}

} // namespace GrpcFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
