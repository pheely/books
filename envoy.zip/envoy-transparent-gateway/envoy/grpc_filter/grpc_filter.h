#pragma once

#include <string>

#include "envoy/server/filter_config.h"
#include "envoy/api/api.h"

#include "source/common/buffer/buffer_impl.h"
#include "source/common/common/logger.h"
#include "source/common/grpc/codec.h"
#include "source/common/protobuf/protobuf.h"

#include "grpc_filter/grpc_filter.pb.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace GrpcFilter {

class GrpcConfig : public Logger::Loggable<Logger::Id::misc> {
public:
  GrpcConfig(const envoy::http::grpc_filter::Config& proto_config, Api::Api& api);

  const std::string& descriptor_file() const { return descriptor_file_; }
  const std::string& method_path() const { return method_path_; }
  const Protobuf::Message *prototype_message() const { return prototype_message_; }
  const Protobuf::Descriptor *message_descriptor() const { return message_descriptor_; }
  const Protobuf::FieldDescriptor *field_descriptor() const { return field_descriptor_; }

private:
  const std::string descriptor_file_;
  const std::string service_name_;
  const std::string method_name_;
  const std::string field_name_;

  Protobuf::DescriptorPool descriptor_pool_;
  Protobuf::DynamicMessageFactory factory_;

  const Protobuf::Message * prototype_message_;
  const Protobuf::Descriptor * message_descriptor_;
  const Protobuf::FieldDescriptor * field_descriptor_;
  std::string method_path_;
};

using GrpcConfigSharedPtr = std::shared_ptr<GrpcConfig>;

class GrpcFilter : public Http::StreamDecoderFilter, public Logger::Loggable<Logger::Id::misc> {
public:
  GrpcFilter(GrpcConfigSharedPtr);
  ~GrpcFilter();

  // Http::StreamFilterBase
  void onDestroy() override;

  // Http::StreamDecoderFilter
  Http::FilterHeadersStatus decodeHeaders(Http::RequestHeaderMap&, bool) override;
  Http::FilterDataStatus decodeData(Buffer::Instance&, bool) override;
  Http::FilterTrailersStatus decodeTrailers(Http::RequestTrailerMap&) override;
  void setDecoderFilterCallbacks(Http::StreamDecoderFilterCallbacks&) override;

private:
  const GrpcConfigSharedPtr config_;
  Http::StreamDecoderFilterCallbacks* decoder_callbacks_;

  bool matched_method_path_ = false;

  Grpc::Decoder decoder_;
};

} // namespace GrpcFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
