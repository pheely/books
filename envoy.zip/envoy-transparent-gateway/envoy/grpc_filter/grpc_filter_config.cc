#include <string>

#include "envoy/registry/registry.h"

#include "grpc_filter/grpc_filter.pb.h"
#include "grpc_filter/grpc_filter.pb.validate.h"

#include "grpc_filter.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace GrpcFilter {

class GrpcFilterConfig : public Server::Configuration::NamedHttpFilterConfigFactory {
public:
  Http::FilterFactoryCb createFilterFactoryFromProto(const Protobuf::Message& proto_config,
                                                     const std::string&,
                                                     Server::Configuration::FactoryContext& context) override {

    return createFilter(Envoy::MessageUtil::downcastAndValidate<const envoy::http::grpc_filter::Config&>(
                            proto_config, context.messageValidationVisitor()),
                        context);
  }

  /**
   *  Return the Protobuf Message that represents your config incase you have config proto
   */
  ProtobufTypes::MessagePtr createEmptyConfigProto() override {
    return ProtobufTypes::MessagePtr{new envoy::http::grpc_filter::Config()};
  }

  std::string name() const override { return "grpc_filter"; }

private:
  Http::FilterFactoryCb createFilter(const envoy::http::grpc_filter::Config& proto_config, Server::Configuration::FactoryContext& context) {
    GrpcConfigSharedPtr config = std::make_shared<GrpcConfig>(proto_config, context.api());

    return [config](Http::FilterChainFactoryCallbacks& callbacks) -> void {
      auto filter = new GrpcFilter(config);
      callbacks.addStreamDecoderFilter(Http::StreamDecoderFilterSharedPtr{filter});
    };
  }
};

/**
 * Static registration for this filter. @see RegisterFactory.
 */
static Registry::RegisterFactory<GrpcFilterConfig, Server::Configuration::NamedHttpFilterConfigFactory>
    register_;

} // namespace GrpcFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
