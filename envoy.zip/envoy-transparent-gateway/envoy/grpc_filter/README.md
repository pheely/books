# GRPC filter

The included example config _envoy-grpc-filter.yaml_ will work with the example GRPC server/client found at [Hello World Example with TLS](https://github.com/grpc/grpc-java/tree/master/examples/example-tls#hello-world-example-with-tls)
