#include <string>

#include "envoy/registry/registry.h"
#include "source/extensions/filters/http/common/factory_base.h"

#include "pubsub_filter/pubsub_filter.pb.h"
#include "pubsub_filter/pubsub_filter.pb.validate.h"

#include "pubsub_filter_http_client.h"
#include "pubsub_filter.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubFilter {

class PubsubFilterConfigFactory : public Common::FactoryBase<envoy::http::pubsub_filter::Config> {
public:
  PubsubFilterConfigFactory() : FactoryBase("pubsub_filter") {}

private:
  Http::FilterFactoryCb createFilterFactoryFromProtoTyped(
      const envoy::http::pubsub_filter::Config& proto_config, const std::string&,
      Server::Configuration::FactoryContext& factory_context) override {
    auto filter_config = std::make_shared<PubsubConfig>(proto_config);

    const auto client_config =
        std::make_shared<Extensions::HttpFilters::PubsubFilter::ClientConfig>(proto_config);

    return [filter_config, client_config,
            &factory_context](Http::FilterChainFactoryCallbacks& callbacks) {
      auto client = std::make_unique<Extensions::HttpFilters::PubsubFilter::HttpClient>(
          factory_context.clusterManager(), client_config);

      callbacks.addStreamFilter(std::make_shared<PubsubFilter>(filter_config, std::move(client)));
    };
  }
};

/**
 * Static registration for the gRPC stats filter. @see RegisterFactory.
 */
REGISTER_FACTORY(PubsubFilterConfigFactory, Server::Configuration::NamedHttpFilterConfigFactory);

} // namespace PubsubFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
