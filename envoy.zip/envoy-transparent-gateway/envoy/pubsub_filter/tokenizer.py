#
# FLASK_APP=tokenizer.py flask run
#

import flask
import base64

app = flask.Flask(__name__)

@app.route('/tokenize', methods=['POST'])
def tokenize():
    pubsub_publish_message = flask.request.get_json()
    for message in pubsub_publish_message['messages']:
        d = base64.b64decode(message['data'])
        message['data'] = base64.b64encode(b'xxx ' + d + b' xxx').decode()
    return pubsub_publish_message
