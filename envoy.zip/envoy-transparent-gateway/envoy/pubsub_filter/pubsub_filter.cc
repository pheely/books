#include <string>

#include "pubsub_filter.h"

#include "envoy/server/filter_config.h"
#include "envoy/buffer/buffer.h"
#include "envoy/grpc/status.h"
#include "source/common/protobuf/protobuf.h"
#include "source/common/protobuf/utility.h"
#include "source/common/grpc/common.h"
#include "source/common/common/enum_to_int.h"

#include "google/pubsub/v1/pubsub.pb.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubFilter {

const std::string PUBLISH_METHOD_PATH = "/google.pubsub.v1.Publisher/Publish";

PubsubConfig::PubsubConfig(const envoy::http::pubsub_filter::Config&) {}

PubsubFilter::PubsubFilter(PubsubConfigSharedPtr config, HttpClientImplPtr client)
    : config_(config), client_(std::move(client)) {}

PubsubFilter::~PubsubFilter() {}

void PubsubFilter::onDestroy() {
      ENVOY_LOG(debug, "onDestroy");
      client_->cancel();
}

Http::FilterHeadersStatus PubsubFilter::decodeHeaders(Http::RequestHeaderMap& headers, bool) {
  if (Grpc::Common::hasGrpcContentType(headers)) {
    if (headers.Path()) {
      if (headers.Path()->value().getStringView() == PUBLISH_METHOD_PATH) {
        matched_method_path_ = true;
      }
    }
  }
  return Http::FilterHeadersStatus::Continue;
}

namespace {
// use this because google::protobuf::Message::DebugString() formats with newlines
[[maybe_unused]] static std::string
protobuf_debug_string(const google::protobuf::Message& message) {
  std::string debug_string;

  google::protobuf::TextFormat::Printer printer;
  printer.SetSingleLineMode(true);

  printer.PrintToString(message, &debug_string);
  return debug_string;
}
} // namespace

Http::FilterDataStatus PubsubFilter::decodeData(Buffer::Instance& data_buffer, bool end_stream) {
  if (!matched_method_path_)
    return Http::FilterDataStatus::Continue;


  end_stream_ = end_stream;
  std::vector<Grpc::Frame> frames;
  decoder_.decode(data_buffer, frames); // empties the buffer
  // ENVOY_LOG(debug, "Frame size = {}", frames.size());

  auto& frame{frames[0]}; // assume there is only one frame
                          // we were doing
                          // for (auto& frame : frames) {}
  google::pubsub::v1::PublishRequest publish_request;
  if (frames.size() > 0 && publish_request.ParseFromString(frame.data_.get()->toString())) {
    // Save original request from pubsub in case there is an error
    original_publish_request = publish_request;
    // ENVOY_LOG(debug, "Decode Data original message : {}", protobuf_debug_string(original_publish_request));
    std::string json_request_string;
    std::string traceId, spanId, logtrace;
    for (auto& received_message : *publish_request.mutable_messages()) {
      auto& attributes = *received_message.mutable_attributes();
      traceId = attributes.contains("X-B3-TraceId") ? attributes.find("X-B3-TraceId")-> second : std::string ();
      spanId = attributes.contains("X-B3-SpanId") ? attributes.find("X-B3-SpanId")-> second : std::string ();
      logtrace.append("[xb3TraceId:"+traceId+",xb3SpanId:"+spanId+"]");
    }
    ENVOY_LOG(debug,"encodeData: {}", logtrace);
    //Should we not check the status?
    const auto status = google::protobuf::util::MessageToJsonString(publish_request, &json_request_string);
    if (status.ok()) {
      ENVOY_LOG(debug, "Starting Call {}", decoder_callbacks_->streamId());
      client_->call(*this, json_request_string);
    }
  }
  return Http::FilterDataStatus::StopIterationNoBuffer;
}

void PubsubFilter::onComplete(const std::string& body, uint64_t grpc_status) {
  google::pubsub::v1::PublishRequest publish_request;

  // ENVOY_LOG(debug, "grpc_status: {}, body: {}", grpc_status, body);
  if(grpc_status != enumToInt(Grpc::Status::Ok)) {
    ENVOY_LOG(debug, "Error occurred, {}:{}", grpc_status, body);
    auto modified_headers = [](Http::HeaderMap&) -> void {};  
    decoder_callbacks_->sendLocalReply(Http::Code::OK, body, modified_headers, grpc_status, body);
  } else if (grpc_status == enumToInt(Grpc::Status::Ok) && 
  google::protobuf::util::JsonStringToMessage(body, &publish_request).ok()) {
    ENVOY_LOG(debug, "Successful Call");
    // ENVOY_LOG(debug, "new request {}", protobuf_debug_string(publish_request));
    auto frame_buffer = Grpc::Common::serializeToGrpcFrame(publish_request);
    Buffer::OwnedImpl data_buffer;
    data_buffer.add(*frame_buffer.get());
    decoder_callbacks_->injectDecodedDataToFilterChain(data_buffer, end_stream_);
  } else {
    grpc_status = Grpc::Status::Internal;
    std::string error_message = "Error: Message not in pubsub format from upstream service";   
    auto modified_headers = [](Http::HeaderMap&) -> void {};  
    decoder_callbacks_->sendLocalReply(Http::Code::OK, body, modified_headers, grpc_status, error_message);
  }
  // continueDecoding();
}

Http::FilterTrailersStatus PubsubFilter::decodeTrailers(Http::RequestTrailerMap&) {
  return Http::FilterTrailersStatus::Continue;
}

void PubsubFilter::setDecoderFilterCallbacks(Http::StreamDecoderFilterCallbacks& callbacks) {
  // ENVOY_LOG(debug, "setDecoderFilterCallbacks");
  decoder_callbacks_ = &callbacks;
}

Http::Filter1xxHeadersStatus PubsubFilter::encode1xxHeaders(Http::ResponseHeaderMap&) {
  return Http::Filter1xxHeadersStatus::Continue;
}

Http::FilterHeadersStatus PubsubFilter::encodeHeaders(Http::ResponseHeaderMap& , bool) {
  ENVOY_LOG(debug, "encodeHeaders, {}", decoder_callbacks_->streamId());
  return Http::FilterHeadersStatus::Continue;
}

Http::FilterDataStatus PubsubFilter::encodeData(Buffer::Instance&, bool) {
  ENVOY_LOG(debug, "encodeData, {}", decoder_callbacks_->streamId());
  return Http::FilterDataStatus::Continue;
}

Http::FilterTrailersStatus PubsubFilter::encodeTrailers(Http::ResponseTrailerMap&) {
  return Http::FilterTrailersStatus::Continue;
}

Http::FilterMetadataStatus PubsubFilter::encodeMetadata(Http::MetadataMap&) {
  return Http::FilterMetadataStatus::Continue;
}

void PubsubFilter::setEncoderFilterCallbacks(Http::StreamEncoderFilterCallbacks&) {}

} // namespace PubsubFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
