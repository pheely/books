#pragma once

#include <string>

#include "envoy/server/filter_config.h"
#include "source/common/buffer/buffer_impl.h"
#include "source/common/common/logger.h"
#include "source/common/grpc/codec.h"
#include "google/pubsub/v1/pubsub.pb.h"

#include "pubsub_filter/pubsub_filter.pb.h"
#include "pubsub_filter_http_client.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubFilter {

class PubsubConfig : public Logger::Loggable<Logger::Id::misc> {
public:
  PubsubConfig(const envoy::http::pubsub_filter::Config&);
};

using PubsubConfigSharedPtr = std::shared_ptr<PubsubConfig>;
using BufferPtr = std::unique_ptr<Buffer::OwnedImpl>;
class PubsubFilter : public Http::StreamFilter, public ClientCallbacks, public Logger::Loggable<Logger::Id::misc> {
public:
  PubsubFilter(PubsubConfigSharedPtr, HttpClientImplPtr);
  ~PubsubFilter();

  // Http::StreamFilterBase
  void onDestroy() override;

  // Http::StreamDecoderFilter
  Http::FilterHeadersStatus decodeHeaders(Http::RequestHeaderMap&, bool) override;
  Http::FilterDataStatus decodeData(Buffer::Instance&, bool) override;
  Http::FilterTrailersStatus decodeTrailers(Http::RequestTrailerMap&) override;
  void setDecoderFilterCallbacks(Http::StreamDecoderFilterCallbacks&) override;

  // Http::StreamEncoderFilter
  Http::Filter1xxHeadersStatus encode1xxHeaders(Http::ResponseHeaderMap&) override;
  Http::FilterHeadersStatus encodeHeaders(Http::ResponseHeaderMap&, bool) override;
  Http::FilterDataStatus encodeData(Buffer::Instance&, bool) override;
  Http::FilterTrailersStatus encodeTrailers(Http::ResponseTrailerMap&) override;
  Http::FilterMetadataStatus encodeMetadata(Http::MetadataMap&) override;
  void setEncoderFilterCallbacks(Http::StreamEncoderFilterCallbacks&) override;

  // ClientCallbacks
  void onComplete(const std::string&, uint64_t) override;

private:
  const PubsubConfigSharedPtr config_;
  HttpClientImplPtr client_;
  Http::StreamDecoderFilterCallbacks* decoder_callbacks_;
  bool matched_method_path_ = false;
  Grpc::Decoder decoder_;
  google::pubsub::v1::PublishRequest original_publish_request;
  bool end_stream_ = false;
};

} // namespace PubsubFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
