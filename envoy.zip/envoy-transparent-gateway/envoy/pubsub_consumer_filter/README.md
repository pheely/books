# Pubsub filter

The included example config _envoy-pubsub-filter.yaml_ will work with the Pubsub publisher found at [Getting Started with Cloud Pub/Sub and the Google Cloud Client libraries](https://github.com/GoogleCloudPlatform/java-docs-samples/tree/master/pubsub/cloud-client#getting-started-with-cloud-pubsub-and-the-google-cloud-client-libraries)

Make the following change to the client code to connect to Envoy instead of the default `https://pubsub.googleapis.com:443`:

```diff
--- a/pubsub/cloud-client/src/main/java/com/example/pubsub/PublisherExample.java
+++ b/pubsub/cloud-client/src/main/java/com/example/pubsub/PublisherExample.java
@@ -48,3 +48,3 @@ public class PublisherExample {
       // Create a publisher instance with default settings bound to the topic
-      publisher = Publisher.newBuilder(topicName).build();
+      publisher = Publisher.newBuilder(topicName).setEndpoint("localhost:12000").build();
```

Where `localhost:12000` is the Envoy listener.
