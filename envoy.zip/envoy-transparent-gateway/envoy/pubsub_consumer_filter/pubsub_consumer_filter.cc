#include <string>

#include "pubsub_consumer_filter.h"

#include "envoy/server/filter_config.h"
#include "envoy/buffer/buffer.h"
#include "source/common/protobuf/protobuf.h"
#include "source/common/protobuf/utility.h"
#include "source/common/grpc/common.h"
#include "source/common/common/enum_to_int.h"

#include "google/pubsub/v1/pubsub.pb.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubConsumerFilter {

const std::string STREAMINGPULL_METHOD_PATH = "/google.pubsub.v1.Subscriber/StreamingPull";
const std::string PULL_METHOD_PATH = "/google.pubsub.v1.Subscriber/Pull";
const std::string grpc_status_key = "grpc_status";
const std::string grpc_message_key = "grpc_message";

PubsubConsumerConfig::PubsubConsumerConfig(const envoy::http::pubsub_consumer_filter::Config&) {}

PubsubConsumerFilter::PubsubConsumerFilter(PubsubConsumerConfigSharedPtr config, HttpConsumerClientImplPtr client)
    : config_(config), client_(std::move(client)) {}

PubsubConsumerFilter::~PubsubConsumerFilter() {}

void PubsubConsumerFilter::onDestroy() {
  if(reidentification_needed_){
    ENVOY_LOG(debug, "onDestroy");
    client_->cancel();
  }
}

Http::FilterHeadersStatus PubsubConsumerFilter::decodeHeaders(Http::RequestHeaderMap& headers, bool) {
  if (Grpc::Common::hasGrpcContentType(headers)) {
    if (headers.Path()) {
      if(!(headers.Method() && headers.Scheme() && headers.ContentType() && headers.TE() && headers.UserAgent()) || 
       headers.ContentLength()) {
        ENVOY_LOG(info, "Unexpected Call");
      } else if ((headers.Path()->value().getStringView() == STREAMINGPULL_METHOD_PATH ||
      headers.Path()->value().getStringView() == PULL_METHOD_PATH)) {
        matched_method_path_ = true;
      } 
    }
  }
  return Http::FilterHeadersStatus::Continue;
}

namespace {
// use this because google::protobuf::Message::DebugString() formats with newlines
[[maybe_unused]] static std::string
protobuf_debug_string(const google::protobuf::Message& message) {
  std::string debug_string;

  google::protobuf::TextFormat::Printer printer;
  printer.SetSingleLineMode(true);

  printer.PrintToString(message, &debug_string);
  return debug_string;
}
} // namespace

Http::FilterDataStatus PubsubConsumerFilter::decodeData(Buffer::Instance& data, bool) {
  google::pubsub::v1::StreamingPullRequest pull_request;
  if (matched_method_path_ == true){
    std::vector<Grpc::Frame> frames;
    decoder_.decode(data, frames); // empties the buffer

    auto& frame{frames[0]}; // assume there is only one frame
                          // we were doing
                          // for (auto& frame : frames) {}
    
// Check if subscription needs reidentification and save consumer policy for later
    if (pull_request.ParseFromString(frame.data_.get()->toString())){
      std::string subscription = pull_request.subscription();
      std::size_t start = subscription.find(subscription_path) + subscription_path.length();
      std::size_t end = subscription.find(subscription_suffix + immutable_suffix_indicator);
      consumer_policy = subscription.substr(start, end - start + subscription_suffix.length());
      if(consumer_policy.size() >= subscription_suffix.size() && 
      consumer_policy.compare(consumer_policy.size() - subscription_suffix.size(), consumer_policy.size(), subscription_suffix) == 0) {
        reidentification_needed_ = true;
        std::size_t suffix = consumer_policy.find(subscription_suffix); 
        consumer_policy = consumer_policy.substr(0, suffix);
        ENVOY_LOG(debug, "decodeData: reidentification required, consumer_policy = {}", consumer_policy);
      } else {
        reidentification_needed_ = false;
        ENVOY_LOG(debug, "decodeData: reidentification not required");
      }     
    }
  // Put data back otherwise it won't be available later
  auto buffer = Grpc::Common::serializeToGrpcFrame(pull_request);
  data.add(*buffer.get());
  }
  return Http::FilterDataStatus::Continue;
}

void PubsubConsumerFilter::onComplete(const std::string& body, uint64_t grpc_status) {
  google::pubsub::v1::StreamingPullResponse pull_response;

  ENVOY_LOG(debug, "onComplete: grpc_status = {}", grpc_status);
  

  if(grpc_status != enumToInt(Grpc::Status::Ok)) {
    error_counter++;
    ENVOY_LOG(debug, "onComplete: Error occurred, error count: {}", error_counter);
    grpc_message = body;
    pull_response = original_pull_response;
  } else if (grpc_status == enumToInt(Grpc::Status::Ok) && 
  google::protobuf::util::JsonStringToMessage(body, &pull_response).ok()) {
    // ENVOY_LOG(debug, "onComplete: new request {}", protobuf_debug_string(pull_response));
    grpc_message = "";
  } else {
    grpc_status = enumToInt(Grpc::Status::Internal);
    grpc_message = "onComplete: Message not in pubsub format";
    pull_response = original_pull_response;
  }
  pull_response = errorHandling(pull_response, grpc_status, grpc_message);
  auto frame_buffer = Grpc::Common::serializeToGrpcFrame(pull_response);
  Buffer::OwnedImpl data_buffer;
  data_buffer.add(*frame_buffer.get());
  encoder_callbacks_->injectEncodedDataToFilterChain(data_buffer, end_stream_);

  ENVOY_LOG(debug, "onComplete: grpc_message = {}", grpc_message);
  // continueEncoding();
}

google::pubsub::v1::StreamingPullResponse PubsubConsumerFilter::errorHandling(google::pubsub::v1::StreamingPullResponse pull_response,
uint64_t grpc_code, std::string grpc_message){
  for (auto& received_message : *pull_response.mutable_received_messages()) {
    auto& message = *received_message.mutable_message();
    // if(grpc_code != Grpc::Status::Ok){
    //   message.set_data(grpc_message);
    // }
    auto& attributes = *message.mutable_attributes();
    google::protobuf::MapPair<std::string, std::string> grpc_status_attribute { grpc_status_key, std::to_string(grpc_code)};
    attributes.insert( grpc_status_attribute );
    // 1024 bytes is the may length of a pubsub attribute
    google::protobuf::MapPair<std::string, std::string> grpc_message_attribute { grpc_message_key, grpc_message.substr(0, 1024)};
    attributes.insert( grpc_message_attribute );
  }
  return pull_response;
}

Http::FilterTrailersStatus PubsubConsumerFilter::decodeTrailers(Http::RequestTrailerMap&) {
  return Http::FilterTrailersStatus::Continue;
}

void PubsubConsumerFilter::setDecoderFilterCallbacks(Http::StreamDecoderFilterCallbacks& callbacks) {
  // ENVOY_LOG(debug, "setDecoderFilterCallbacks");
  decoder_callbacks_ = &callbacks;
}

Http::Filter1xxHeadersStatus PubsubConsumerFilter::encode1xxHeaders(Http::ResponseHeaderMap&) {
  return Http::Filter1xxHeadersStatus::Continue;
}

Http::FilterHeadersStatus PubsubConsumerFilter::encodeHeaders(Http::ResponseHeaderMap&, bool) {
  // ENVOY_LOG(debug, "encodeHeaders, matched_method_path_ = {}", matched_method_path_);
  return Http::FilterHeadersStatus::Continue;
}

Http::FilterDataStatus PubsubConsumerFilter::encodeData(Buffer::Instance& data_buffer, bool end_stream)  {
  ENVOY_LOG(debug, "encodeData: reidentification_needed_ = {}", reidentification_needed_);
  
  if (!reidentification_needed_){
    return Http::FilterDataStatus::Continue;
  }
  end_stream_ = end_stream;
  std::vector<Grpc::Frame> frames;
  decoder_.decode(data_buffer, frames); // empties the buffer
  
  // auto& frame{frames[0]}; // assume there is only one frame
                          // we were doing
                          // for (auto& frame : frames) {}
  for (auto& frame : frames) {
  google::pubsub::v1::StreamingPullResponse pull_response;
  if (frames.size() !=0 && pull_response.ParseFromString(frame.data_.get()->toString())) {
    // Save original response from pubsub in case there is an error
    original_pull_response.ParseFromString(frame.data_.get()->toString());
    // ENVOY_LOG(debug, "original request {}", protobuf_debug_string(pull_response));
    ENVOY_LOG(debug, "encodeData: Number of messages in pull_response: {}", pull_response.received_messages_size());
    ENVOY_LOG(debug, "encodeData: consumer_policy= {}", consumer_policy);
    std::string traceId, spanId, logtrace;
    for (auto& received_message : *pull_response.mutable_received_messages()) {
      auto& message = *received_message.mutable_message();
      auto& attributes = *message.mutable_attributes();
      traceId = attributes.contains("X-B3-TraceId") ? attributes.find("X-B3-TraceId")-> second : std::string ();
      spanId = attributes.contains("X-B3-SpanId") ? attributes.find("X-B3-SpanId")-> second : std::string ();
      logtrace.append("[xb3TraceId:"+traceId+",xb3SpanId:"+spanId+"]");
      google::protobuf::MapPair<std::string, std::string> policy {subscription_key, consumer_policy};
      attributes.insert( policy );
      // break; //PRC only checks the first entry so we can break here safely
    }
    ENVOY_LOG(debug,"encodeData: {}", logtrace);
    std::string json_request_string;
    //Should we not check the status?
    const auto status = google::protobuf::util::MessageToJsonString(pull_response, &json_request_string);
    // ENVOY_LOG(debug, "encodeData: json request {}", json_request_string);
    if (status.ok()) {
      ENVOY_LOG(debug, "encodeData: Starting Call");
      client_->call(*this, json_request_string);
      message_counter++;
      }
    }
  }

  return Http::FilterDataStatus::StopIterationNoBuffer;
}

Http::FilterTrailersStatus PubsubConsumerFilter::encodeTrailers(Http::ResponseTrailerMap&) {
  return Http::FilterTrailersStatus::Continue;
}

Http::FilterMetadataStatus PubsubConsumerFilter::encodeMetadata(Http::MetadataMap&) {
  return Http::FilterMetadataStatus::Continue;
}

void PubsubConsumerFilter::setEncoderFilterCallbacks(Http::StreamEncoderFilterCallbacks& callbacks) {
  // ENVOY_LOG(debug, "setEncoderFilterCallbacks");
  encoder_callbacks_ = &callbacks;
}

void PubsubConsumerFilter::continueEncoding() {
  message_counter--;
  ENVOY_LOG(debug, "message count is: {}", message_counter);
  if (message_counter ==  0) {
    ENVOY_LOG(debug, "Continue Encoding");
    encoder_callbacks_->continueEncoding();
  }
}

} // namespace PubsubConsumerFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
