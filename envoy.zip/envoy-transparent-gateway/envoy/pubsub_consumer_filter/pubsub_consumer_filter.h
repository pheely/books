#pragma once

#include <string>

#include "envoy/server/filter_config.h"
#include "source/common/buffer/buffer_impl.h"
#include "source/common/common/logger.h"
#include "source/common/grpc/codec.h"
#include "google/pubsub/v1/pubsub.pb.h"

#include "pubsub_consumer_filter/pubsub_consumer_filter.pb.h"
#include "pubsub_consumer_filter_http_client.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubConsumerFilter {

class PubsubConsumerConfig : public Logger::Loggable<Logger::Id::misc> {
public:
  PubsubConsumerConfig(const envoy::http::pubsub_consumer_filter::Config&);
};

using PubsubConsumerConfigSharedPtr = std::shared_ptr<PubsubConsumerConfig>;
using BufferPtr = std::unique_ptr<Buffer::OwnedImpl>;
class PubsubConsumerFilter : public Http::StreamFilter, public ClientCallbacks, public Logger::Loggable<Logger::Id::misc> {
public:
  PubsubConsumerFilter(PubsubConsumerConfigSharedPtr, HttpConsumerClientImplPtr);
  ~PubsubConsumerFilter();

  // Http::StreamFilterBase
  void onDestroy() override;

  // Http::StreamDecoderFilter
  Http::FilterHeadersStatus decodeHeaders(Http::RequestHeaderMap&, bool) override;
  Http::FilterDataStatus decodeData(Buffer::Instance&, bool) override;
  Http::FilterTrailersStatus decodeTrailers(Http::RequestTrailerMap&) override;
  void setDecoderFilterCallbacks(Http::StreamDecoderFilterCallbacks&) override;

  // Http::StreamEncoderFilter
  Http::Filter1xxHeadersStatus encode1xxHeaders(Http::ResponseHeaderMap&) override;
  Http::FilterHeadersStatus encodeHeaders(Http::ResponseHeaderMap&, bool) override;
  Http::FilterDataStatus encodeData(Buffer::Instance&, bool) override;
  Http::FilterTrailersStatus encodeTrailers(Http::ResponseTrailerMap&) override;
  Http::FilterMetadataStatus encodeMetadata(Http::MetadataMap&) override;
  void setEncoderFilterCallbacks(Http::StreamEncoderFilterCallbacks&) override;
  // void encodeComplete() override;

  // ClientCallbacks
  void onComplete(const std::string&, uint64_t) override;

private:
  // FilterReturn is used to capture what the return code should be to the filter chain.
  // if this filter is either in the middle of calling the service or the result is denied then
  // the filter chain should stop. Otherwise the filter chain can continue to the next filter.
  void continueEncoding();
  google::pubsub::v1::StreamingPullResponse errorHandling(google::pubsub::v1::StreamingPullResponse, uint64_t, std::string);

  enum class State { NotStarted, Calling, Complete };

  const PubsubConsumerConfigSharedPtr config_;
  HttpConsumerClientImplPtr client_;
  Http::StreamDecoderFilterCallbacks* decoder_callbacks_;
  Http::StreamEncoderFilterCallbacks* encoder_callbacks_;
  bool matched_method_path_ = false;
  bool reidentification_needed_ = false;
  Grpc::Decoder decoder_;
  // Buffer::OwnedImpl saved_data_;
  google::pubsub::v1::StreamingPullResponse original_pull_response;
  std::string consumer_policy;
  const std::string subscription_key = "consumerpolicy";
  const std::string subscription_suffix = "-pcr";
  const std::string subscription_path  = "/subscriptions/";
  const std::string immutable_suffix_indicator  = "--";
  std::string grpc_message;
  uint64_t message_counter = 0;
  uint64_t error_counter = 0;
  // State state_{State::NotStarted};
  bool end_stream_ = false;
};

} // namespace PubsubConsumerFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
