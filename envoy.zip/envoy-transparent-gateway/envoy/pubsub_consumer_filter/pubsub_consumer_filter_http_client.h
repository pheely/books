#pragma once

#include <string>

#include "envoy/upstream/cluster_manager.h"
#include "source/common/common/logger.h"
#include "source/common/http/async_client_utility.h"

#include "pubsub_consumer_filter/pubsub_consumer_filter.pb.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubConsumerFilter {

// enum class ClientStatus { Success, Failure };

class ClientCallbacks {
public:
  virtual ~ClientCallbacks() = default;

  virtual void onComplete(const std::string&, uint64_t) PURE;
};

class ClientConfig : public Logger::Loggable<Logger::Id::misc> {
public:
  ClientConfig(const envoy::http::pubsub_consumer_filter::Config&);

  const std::string& cluster() { return cluster_name_; };
  const std::string& path() { return path_; };

private:
  const std::string cluster_name_;
  const std::string path_;
};

using ClientConfigSharedPtr = std::shared_ptr<ClientConfig>;


class HttpClient : public Http::AsyncClient::Callbacks, Logger::Loggable<Logger::Id::misc> {
public:
  explicit HttpClient(Upstream::ClusterManager&, ClientConfigSharedPtr);
  ~HttpClient() = default;

  void call(ClientCallbacks&, const std::string&);
  void cancel();

  // Http::AsyncClient::Callbacks
  void onSuccess(const Http::AsyncClient::Request&, Http::ResponseMessagePtr&&) override;
  void onFailure(const Http::AsyncClient::Request&, Http::AsyncClient::FailureReason) override;
  void onBeforeFinalizeUpstreamSpan(Envoy::Tracing::Span&, const Http::ResponseHeaderMap*) override;

private:
  Upstream::ClusterManager& cm_;
  ClientConfigSharedPtr config_;
  // Http::AsyncClient::Request* request_{};
  ClientCallbacks* callbacks_;
  // std::set<Http::AsyncClient::Request*> pending_requests_;
  std::unique_ptr<Http::AsyncClientRequestTracker> active_requests_{
      std::make_unique<Http::AsyncClientRequestTracker>()};
};

using HttpConsumerClientImplPtr = std::unique_ptr<HttpClient>;

} // namespace PubsubConsumerFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
