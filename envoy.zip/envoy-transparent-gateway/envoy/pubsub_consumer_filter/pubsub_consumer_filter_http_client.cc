#include <string>

#include "source/common/http/message_impl.h"
#include "source/common/http/utility.h"
#include "source/common/common/enum_to_int.h"
#include "source/common/runtime/runtime_impl.h"
#include "source/common/common/random_generator.h"
#include "source/common/http/async_client_utility.h"

#include "pubsub_consumer_filter_http_client.h"


namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace PubsubConsumerFilter {

ClientConfig::ClientConfig(const envoy::http::pubsub_consumer_filter::Config& config)
    : cluster_name_(config.cluster()), path_(config.path()) {}

HttpClient::HttpClient(Upstream::ClusterManager& cm, ClientConfigSharedPtr config)
    : cm_(cm), config_(config) {}

void HttpClient::call(ClientCallbacks& callbacks, const std::string& body) {
  ASSERT(body.length() > 0);

  const std::string& cluster_name = config_->cluster();
  if (!cm_.clusters().hasCluster(cluster_name)) {
    ENVOY_LOG(debug, "HttpClient::call: cluster '{}' does not exist", cluster_name);
    return;
  }

  Random::RandomGeneratorImpl random;
  Http::RequestMessagePtr message(new Http::RequestMessageImpl());
  message->headers().setReferenceMethod(Http::Headers::get().MethodValues.Post);
  message->headers().setPath(config_->path());
  message->body().add(body);
  message->headers().setReferenceContentType(Http::Headers::get().ContentTypeValues.Json);
  message->headers().setContentLength(body.length());
  message->headers().setHost(cluster_name);
  std::string uuid = random.uuid();
  message->headers().setRequestId(uuid);

  ENVOY_LOG(debug, "Calling PCR with request: {}", uuid);

  Http::AsyncClient::Request* request = cm_.getThreadLocalCluster(cluster_name)->httpAsyncClient()
                 .send(std::move(message), *this, Http::AsyncClient::RequestOptions());
  // pending_requests_.insert(request_);
  //if an error happens you dont want to add it to the active_request
  //you will get an assertion error                
  if(request != nullptr){
    active_requests_->add(*request);
  }
  callbacks_ = &callbacks;
}

void HttpClient::cancel() {
  ENVOY_LOG(debug, "cancel");
  ASSERT(callbacks_);
  active_requests_.reset();
  callbacks_ = nullptr;
}

void HttpClient::onBeforeFinalizeUpstreamSpan(Envoy::Tracing::Span&, const Http::ResponseHeaderMap*){
}
void HttpClient::onSuccess(const Http::AsyncClient::Request& request,
                           Http::ResponseMessagePtr&& response) {

  active_requests_->remove(request);
  uint64_t response_code = Http::Utility::getResponseStatus(response->headers());
  // ENVOY_LOG(debug, "HttpClient::onSuccess, response code = {}", response_code);

  const std::string response_body{response->bodyAsString()};
  // ENVOY_LOG(debug, "HttpClient::onSuccess, response = {}", response_body);

  
  // Status::WellKnownGrpcStatus grpc_code = Grpc::Utility::httpToGrpcStatus(enumToInt(response_code));
  uint64_t grpc_status;
  switch (response_code) {
  // 200
  case enumToInt(Http::Code::OK):
    grpc_status = enumToInt(Grpc::Status::Ok);
    break;
  // 400
  case enumToInt(Http::Code::BadRequest):
    grpc_status = enumToInt(Grpc::Status::InvalidArgument);
    break;
  // 404
  case enumToInt(Http::Code::NotFound):
    grpc_status = enumToInt(Grpc::Status::NotFound);
    break;
  // 403
  case enumToInt(Http::Code::Forbidden):
    grpc_status = enumToInt(Grpc::Status::PermissionDenied);
    break;
  // 500 or 502
  case enumToInt(Http::Code::InternalServerError):
  case enumToInt(Http::Code::BadGateway):
    grpc_status = enumToInt(Grpc::Status::Internal);
    break;
  // 504
  case enumToInt(Http::Code::GatewayTimeout):
    grpc_status = enumToInt(Grpc::Status::DeadlineExceeded);
    break;
  //503
  case enumToInt(Http::Code::ServiceUnavailable):
    grpc_status = enumToInt(Grpc::Status::Unavailable);
    break;
  default:
    grpc_status = enumToInt(Grpc::Status::Unknown);
    break;
  }
  callbacks_->onComplete(response_body, grpc_status);
}

void HttpClient::onFailure(const Http::AsyncClient::Request& request, Http::AsyncClient::FailureReason) {
  ENVOY_LOG(info, "HttpClient::onFailure");
  active_requests_->remove(request);
  // callbacks_->onComplete(std::string{}, ClientStatus::Failure);
}

} // namespace PubsubConsumerFilter
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
